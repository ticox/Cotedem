<?php



//define('BASE_URL', 'http://192.168.0.50/');
define('BASE_URL', 'http://localhost/cotedem/');
//define('BASE_URL', 'http://192.168.0.101/cumanax/');
//define('BASE_URL', 'http://americas89.no-ip.info:8080/didactico/');
//define('DEFAULT_CONTROLLER', 'faceblocked');
define('DEFAULT_CONTROLLER', 'principal');
//define('DEFAULT_LAYOUT', 'layout_legna');
define('DEFAULT_LAYOUT', 'cotedem');
define('APP_NAME', 'COTEDEM');
define('APP_SLOGAN', 'COTEDEM');
define('APP_COMPANY', '');
define('APP_TLF', '');
define('APP_EMAIL', '');
define('SESSION_TIME', 1000000);
define('HASH_KEY', '4f6a6d832be79');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'cotedem');
define('DB_CHAR', 'utf8');


?>