<!--</div>
</div>

<div class="pie_head"> 
	designed by ING. Angel Charlot. <span class="glyphicon glyphicon-off" aria-hidden="true"> </span> 
	<br>
	legna18205@gmail.com. <span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> 
	<br>
	EPS Comercializadora de alimentos C.A. (departament of informatic)<span class="glyphicon glyphicon-lock" aria-hidden="true"> </span> 
	<br>

  
</div>
<section class="">
</section>
<div class="">
 </div>


<script src="<?php echo BASE_URL; ?>public/js/jquery.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/alertify.min.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/config.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/jquery.validationEngine.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/jquery.validationEngine-es.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/jquery-ui.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/qrcodelib.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/WebCodeCam.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/qr_framework.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/qrcode.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/modalEffects.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/classie.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/modernizr.custom.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/cssParser.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/clockCountdown.js" type="text/javascript"></script>

 <script src="<?php echo $_layoutParams['ruta_js'];?>header.js" type="text/javascript"></script>

<?php if(isset($_layoutParams['js']) && count($_layoutParams['js'])): ?>
    <?php for($i=0; $i < count($_layoutParams['js']); $i++): ?>
        <script src="<?php echo $_layoutParams['js'][$i] ?>" type="text/javascript"></script>
    <?php endfor; ?>
<?php endif; ?>

</body>

</html>-->

 <!--==========================
    New Footer - Nuevo Pie de pagina
  ============================-->
</div>

<footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-info">
            <h3>COTEDEM</h3>
            <p>Somos una empresa ecuatoriana que proporciona soluciones tecnológicas integrales. Nuestra pasión es la tecnología y nuestra meta: optimizar la competitividad de las empresas que confían en nosotros.</p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Otros Links</h4>
            <ul>
              <li><i class="ion-ios-arrow-right"></i> <a href="#intro">Inicio</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#about">Nosotros</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#services">Servicios</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#ubicacion">Ubicación</a></li>
              <!-- <li><i class="ion-ios-arrow-right"></i> <a href="">Terminos de Servicio</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="">Politicas de Privacidad</a></li> -->
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contactanos</h4>
            <p>
              Ecuador - Quito, Pichincha <br>
              Sancho Hacho N58-187 y Luis Tufiño<br>
              <br>
              <strong>Telefono:</strong> +593 99 257 3097<br>
              <strong>Correo:</strong> info@cotedem.com<br>
            </p>

            <div class="social-links">
              <a href="javascript:null()" class="twitter"><i class="fa fa-twitter"></i></a>
              <a href="javascript:null()" class="facebook"><i class="fa fa-facebook"></i></a>
              <a href="javascript:null()" class="instagram"><i class="fa fa-instagram"></i></a>
              <a href="javascript:null()" class="google-plus"><i class="fa fa-google-plus"></i></a>
              <a href="javascript:null()" class="linkedin"><i class="fa fa-linkedin"></i></a>
            </div>

          </div>

          <div class="col-lg-3 col-md-6 footer-newsletter">
            <h4>Suscribase con nosotros</h4>
            <p>Suscribase y reciba nuestras ofertas por correo electronico.</p>
            <form  method="post">
              <input type="email" name="email"><input type="submit"  value="Subscribe">
            </form>
          </div>

        </div>
      </div>
    </div>

<div class="container">
      <div class="copyright">
        &copy; Copyright <strong>COTEDEM</strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!--
          Sin borrar mi firma no te pases de verga hahahaha xd
        -->
        Designed by <a target="_blank" href="https://cotedem.com/">COTEDEM</a>
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="<?php echo BASE_URL; ?>lib/jquery/jquery.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/jquery/jquery-migrate.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/easing/easing.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/superfish/hoverIntent.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/superfish/superfish.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/wow/wow.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/waypoints/waypoints.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/counterup/counterup.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/isotope/isotope.pkgd.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/lightbox/js/lightbox.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/touchSwipe/jquery.touchSwipe.min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="<?php echo BASE_URL; ?>public/js/alertify.min.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/config.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/jquery.validationEngine.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/jquery.validationEngine-es.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/modalEffects.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/jquery-ui.js" type="text/javascript"></script>
  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

<?php if(isset($_layoutParams['js']) && count($_layoutParams['js'])): ?>
    <?php for($i=0; $i < count($_layoutParams['js']); $i++): ?>
        <script src="<?php echo $_layoutParams['js'][$i] ?>" type="text/javascript"></script>
    <?php endfor; ?>
<?php endif; ?>

  <script type="text/javascript">
$(window).load(function() {
    $(".loader").fadeOut("slow");
});
</script>


</body>
</html>