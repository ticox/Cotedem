//var base_url = 'http://192.168.0.101/cumanax/';
//var base_url = 'http://192.168.0.50/';
var base_url = 'http://localhost/cotedem/';

$(document).on('click', '#inicio', function() {


location.href=base_url; 	
});